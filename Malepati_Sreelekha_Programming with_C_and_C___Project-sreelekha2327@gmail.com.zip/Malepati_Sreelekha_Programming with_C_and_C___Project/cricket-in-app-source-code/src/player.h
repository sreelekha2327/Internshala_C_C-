#include <string>

class Player{

	public:
		Player();
		std::string name;
		int index;
		int runScored;
		int ballsPlayed;
		int ballsBowled;
		int runsGiven;
		int wicketsTaken;

};

