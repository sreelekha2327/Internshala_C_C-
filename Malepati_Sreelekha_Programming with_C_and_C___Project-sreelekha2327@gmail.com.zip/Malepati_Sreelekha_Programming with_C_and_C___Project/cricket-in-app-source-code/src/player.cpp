#include "player.h"  // <string>

Player::Player(){

			 runScored = 0;
			 ballsPlayed = 0;
			 ballsBowled = 0;
			 runsGiven = 0;
			 wicketsTaken = 0;
}
